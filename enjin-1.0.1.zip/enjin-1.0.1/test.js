document.body.className += ' landing is-preload';

$( document ).ready(function() {
    $( "#menu" ).append( $( "#enjin-bar .right" ) );
    $( "#menu" ).append( $( "#enjin-bar-likes" ) );
});

		